internal class Program{
    static void Main(string[] args){
        soapM.serviceClient cliente= new soapM.serviciosClient();
        console.WriteLine("->: "+cliente.hello("Carlos"));
        console.WriteLine("->: "+cliente.par_impar(3));
        console.WriteLine("->: "+cliente.potencia(2,3));
        if(cliente.login("Carlos", "wosita")){
            console.WriteLine("Correcto ");
        }else{
            console.WriteLine("Error Logueo");

        }
        cliente.Close();
        Console.ReadLine();
    }
}